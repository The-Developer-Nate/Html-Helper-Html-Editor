﻿Imports System.IO

Public Class Form1

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        WebBrowser1.DocumentText = RichTextBox1.Text
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        WebBrowser1.Refresh()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim ofd As New OpenFileDialog
        Dim fl As String
        ofd.ShowDialog()
        fl = ofd.FileName
        Dim sr As New StreamReader(fl)
        RichTextBox1.Text = sr.ReadToEnd()
        sr.Close()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim sfd As New SaveFileDialog
        Dim sv As String
        sfd.ShowDialog()
        sv = sfd.FileName
        Dim sw As New StreamWriter(sv)
        sw.Write(RichTextBox1.Text)
        sw.Close()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        RichTextBox1.Text = ""
    End Sub
End Class
